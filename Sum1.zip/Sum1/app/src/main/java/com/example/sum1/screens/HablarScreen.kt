package com.example.sum1.screens

import android.app.Activity
import android.content.pm.PackageManager
import android.speech.RecognizerIntent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.example.sum1.util.sttIntent
import com.example.sum1.viewmodel.MessageViewModel

@Composable
fun HablarScreen(vm: MessageViewModel, onBack: ()->Unit) {
    val ctx = LocalContext.current
    var spoken by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    val sttLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { res ->
        if (res.resultCode == Activity.RESULT_OK) {
            val matches = res.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            spoken = matches?.firstOrNull().orEmpty()
            error = null
        } else {
            error = "No se captó audio o se canceló."
        }
    }

    val askMicPermission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            val intent = sttIntent()
            if (intent.resolveActivity(ctx.packageManager) != null) {
                sttLauncher.launch(intent)
            } else {
                error = "No hay servicio de reconocimiento de voz disponible en este dispositivo."
            }
        } else {
            error = "Permiso de micrófono denegado."
        }
    }

    fun startDictation() {
        val granted = ContextCompat.checkSelfPermission(
            ctx, android.Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED

        if (granted) {
            val intent = sttIntent()
            if (intent.resolveActivity(ctx.packageManager) != null) {
                sttLauncher.launch(intent)
            } else {
                error = "No hay servicio de reconocimiento de voz disponible en este dispositivo."
            }
        } else {
            askMicPermission.launch(android.Manifest.permission.RECORD_AUDIO)
        }
    }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Hablar", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(8.dp))

        error?.let {
            Text(it, color = MaterialTheme.colorScheme.error)
            Spacer(Modifier.height(8.dp))
        }

        OutlinedTextField(
            value = spoken,
            onValueChange = { spoken = it },
            label = { Text("Reconocido") },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(Modifier.height(8.dp))

        Row {
            Button(
                onClick = { startDictation() },
                modifier = Modifier.weight(1f).height(56.dp)
            ) { Text("Dictar") }

            Spacer(Modifier.width(8.dp))

            Button(
                onClick = {
                    if (spoken.isNotBlank()) {
                        vm.input.value = spoken
                        vm.send()
                        spoken = ""
                    } else {
                        error = "No hay texto para enviar."
                    }
                },
                modifier = Modifier.weight(1f).height(56.dp)
            ) { Text("Enviar") }
        }

        Spacer(Modifier.height(8.dp))

        OutlinedButton(
            onClick = onBack,
            modifier = Modifier.fillMaxWidth().height(48.dp)
        ) { Text("Volver") }
    }
}
