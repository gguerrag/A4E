package com.example.sum1.provider

import android.content.ContentProvider
import android.content.ContentValues
import android.database.Cursor
import android.net.Uri
import com.example.sum1.data.local.DbContract
import com.example.sum1.data.local.DbHelper

class MessagesProvider : ContentProvider() {
    companion object {
        const val AUTH = "com.example.sum1.provider"
        val CONTENT_URI: Uri = Uri.parse("content://$AUTH/messages")
    }
    private val table = DbContract.Messages.TABLE

    override fun onCreate(): Boolean = true

    override fun query(uri: Uri, proj: Array<out String>?, sel: String?, args: Array<out String>?, sort: String?): Cursor {
        val db = DbHelper.getInstance(requireNotNull(context)).readableDatabase
        return db.query(table, proj, sel, args, null, null, sort ?: "${DbContract.Messages.CREATED_AT} DESC")
    }

    override fun insert(uri: Uri, values: ContentValues?): Uri? {
        val db = DbHelper.getInstance(requireNotNull(context)).writableDatabase
        db.insertWithOnConflict(table, null, values, 5/*CONFLICT_REPLACE*/)
        context?.contentResolver?.notifyChange(uri, null)
        return uri
    }

    override fun update(uri: Uri, values: ContentValues?, sel: String?, args: Array<out String>?): Int {
        val db = DbHelper.getInstance(requireNotNull(context)).writableDatabase
        val n = db.update(table, values, sel, args); if (n>0) context?.contentResolver?.notifyChange(uri, null); return n
    }

    override fun delete(uri: Uri, sel: String?, args: Array<out String>?): Int {
        val db = DbHelper.getInstance(requireNotNull(context)).writableDatabase
        val n = db.delete(table, sel, args); if (n>0) context?.contentResolver?.notifyChange(uri, null); return n
    }

    override fun getType(uri: Uri) = "vnd.android.cursor.dir/vnd.$AUTH.messages"
}
