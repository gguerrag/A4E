package com.example.sum1.util

inline fun <R> safe(block: () -> R): Result<R> =
    try { Result.success(block()) } catch (t: Throwable) { Result.failure(t) }
