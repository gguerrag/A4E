package com.example.sum1.nav

sealed class NavRouter(val route: String) {
    object Onboard1 : NavRouter("onboard1")
    object Onboard2 : NavRouter("onboard2")
    object Onboard3 : NavRouter("onboard3")
    object Onboard4 : NavRouter("onboard4")
    object Login    : NavRouter("login")
    object Register : NavRouter("register")
    object Forgot   : NavRouter("forgot")
    object Home     : NavRouter("home")
}
