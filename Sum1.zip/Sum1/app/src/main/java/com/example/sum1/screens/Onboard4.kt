package com.example.sum1.screens

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.airbnb.lottie.compose.*
import com.example.sum1.R

@Composable
fun Onboard4Screen(onNext: () -> Unit) = OnboardCommon(
    title = "¡Listo!",
    description = "Comencemos a usar la app.",
    actionText = "Comenzar",
    onNext = onNext,
    illustration = {
        val composition by rememberLottieComposition(
            LottieCompositionSpec.RawRes(R.raw.check)
        )
        val progress by animateLottieCompositionAsState(
            composition = composition,
            iterations = LottieConstants.IterateForever
        )
        LottieAnimation(
            composition = composition,
            progress = { progress },
            modifier = Modifier
                .fillMaxWidth()
                .height(400.dp)
        )
    }
)
