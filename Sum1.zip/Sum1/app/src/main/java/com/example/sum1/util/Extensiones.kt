package com.example.sum1.util

import android.util.Patterns
import com.example.sum1.data.User


fun String.isValidEmail(): Boolean =
    Patterns.EMAIL_ADDRESS.matcher(this).matches()


val User.maskedPassword: String
    get() = "•".repeat(minOf(8, password.length))