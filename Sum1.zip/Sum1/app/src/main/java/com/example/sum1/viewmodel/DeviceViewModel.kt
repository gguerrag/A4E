package com.example.sum1.viewmodel

import android.annotation.SuppressLint
import android.app.Application
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.sum1.data.DeviceRepository
import com.example.sum1.data.UserRepository
import com.google.android.gms.location.LocationServices
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

class DeviceViewModel(app: Application) : AndroidViewModel(app) {

    init { DeviceRepository.init(app.applicationContext) }

    val lastText = mutableStateOf("—")
    val error = mutableStateOf<String?>(null)

    private val fused by lazy {
        LocationServices.getFusedLocationProviderClient(getApplication<Application>())
    }

    private fun currentUserIdOrThrow(): Long =
        UserRepository.allUsers().firstOrNull()?.id?.toLong()
            ?: throw IllegalStateException("No hay usuario actual")

    @SuppressLint("MissingPermission")
    fun captureAndSave() {
        viewModelScope.launch {
            try {
                val uid = currentUserIdOrThrow()
                val loc = fused.lastLocation.await() ?: error("Sin ubicación")
                DeviceRepository.save(uid, loc.latitude, loc.longitude).getOrThrow()
                lastText.value = "${loc.latitude}, ${loc.longitude}"
            } catch (t: Throwable) { error.value = t.message }
        }
    }
}
