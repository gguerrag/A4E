package com.example.sum1.data

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import com.example.sum1.data.local.DbHelper
import com.example.sum1.data.local.LocationDao

object DeviceRepository {
    private lateinit var db: SQLiteDatabase
    private lateinit var dao: LocationDao

    fun init(context: Context) {
        if (!::db.isInitialized) {
            db = DbHelper.getInstance(context).writableDatabase
            dao = LocationDao(db)
        }
    }
    fun save(uid: Long, lat: Double, lng: Double) = runCatching { dao.insert(uid, lat, lng) }
    fun last(uid: Long) = dao.last(uid)
}
