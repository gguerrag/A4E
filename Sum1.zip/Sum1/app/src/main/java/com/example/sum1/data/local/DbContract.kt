package com.example.sum1.data.local

object DbContract {
    const val DB_NAME = "app.db"
    const val DB_VERSION = 1

    object Users {
        const val TABLE = "users"
        const val ID = "id"
        const val EMAIL = "email"
        const val PASSWORD = "password"
        const val CREATED_AT = "createdAt"
        val CREATE = """
            CREATE TABLE $TABLE (
              $ID INTEGER PRIMARY KEY AUTOINCREMENT,
              $EMAIL TEXT NOT NULL UNIQUE,
              $PASSWORD TEXT NOT NULL,
              $CREATED_AT INTEGER NOT NULL
            )
        """.trimIndent()
    }


    object Messages {
        const val TABLE = "messages"
        const val ID = "id"
        const val TEXT = "text"
        const val USER_ID = "userId"
        const val CREATED_AT = "createdAt"
        val CREATE = """
            CREATE TABLE $TABLE (
              $ID INTEGER PRIMARY KEY AUTOINCREMENT,
              $TEXT TEXT NOT NULL,
              $USER_ID INTEGER NOT NULL,
              $CREATED_AT INTEGER NOT NULL,
              FOREIGN KEY($USER_ID) REFERENCES ${Users.TABLE}(${Users.ID}) ON DELETE CASCADE
            )
        """.trimIndent()
    }

    object Locations {
        const val TABLE = "locations"
        const val ID = "id"
        const val USER_ID = "userId"
        const val LAT = "lat"
        const val LNG = "lng"
        const val RECORDED_AT = "recordedAt"
        val CREATE = """
            CREATE TABLE $TABLE (
              $ID INTEGER PRIMARY KEY AUTOINCREMENT,
              $USER_ID INTEGER NOT NULL,
              $LAT REAL NOT NULL,
              $LNG REAL NOT NULL,
              $RECORDED_AT INTEGER NOT NULL,
              FOREIGN KEY($USER_ID) REFERENCES ${Users.TABLE}(${Users.ID}) ON DELETE CASCADE
            )
        """.trimIndent()
    }
}
