package com.example.sum1.data

private const val MAX_USERS = 5
private const val PRELOAD_ON_START = false

enum class PasswordStrength { WEAK, MEDIUM, STRONG }

object UserRepository {
    private val users: Array<User?> = arrayOfNulls(MAX_USERS)
    private var size = 0

    // Datos
    private val PRESEEDED = listOf(
        User(0, "goguerrag@duoc.cl",              "Duoc2025*"),
        User(1, "g.guerragaldames@gmail.com",     "Duoc2025*"),
        User(2, "gguerra@hotmail.com",            "Duoc2025*"),
        User(3, "gonzalo.guerra@live.cl",         "Duoc2025*"),
        User(4, "go.guerra@duocuc.cl",            "Duoc2025*")
    )

    init {
        if (PRELOAD_ON_START) {
            val n = minOf(MAX_USERS, PRESEEDED.size)
            for (i in 0 until n) users[i] = PRESEEDED[i]
            size = n
        }
    }


    fun register(email: String, password: String): Result<Unit> {
        val e = email.trim()
        if (e.isBlank() || password.isBlank())
            return Result.failure(IllegalArgumentException("Email/contraseña obligatorios"))
        if (size >= MAX_USERS)
            return Result.failure(IllegalStateException("Capacidad máxima alcanzada ($MAX_USERS)"))

        // evitar duplicados
        for (u in users) {
            if (u != null && u.email.equals(e, ignoreCase = true))
                return Result.failure(IllegalArgumentException("El usuario ya existe"))
        }

        var i = 0
        while (i < users.size) {
            if (users[i] == null) {
                users[i] = User(i, e, password)
                size++
                return Result.success(Unit)
            }
            i++
        }
        return Result.failure(IllegalStateException("Sin espacio"))
    }


    @Throws(IllegalArgumentException::class, IllegalStateException::class)
    fun registerOrThrow(email: String, password: String) {
        val r = register(email, password)
        r.getOrThrow() // lanza la excepción contenida en Result si falló
    }


    fun findByDomain(domain: String): List<User> =
        users.filterNotNull().filter { it.email.endsWith("@$domain", ignoreCase = true) }


    fun firstStartsWith(prefix: String): User? {
        var found: User? = null
        users.filterNotNull().forEach search@ { u ->
            if (u.email.startsWith(prefix, ignoreCase = true)) {
                found = u
                return@search  // <- etiqueta de lambda
            }
        }
        return found
    }


    fun login(email: String, password: String): Boolean {
        val e = email.trim()
        for (u in users) if (u != null && u.email == e && u.password == password) return true
        return false
    }

    fun recover(email: String): Boolean {
        val e = email.trim()
        for (u in users) if (u != null && u.email.equals(e, true)) return true
        return false
    }

    fun allUsers(): List<User> = users.filterNotNull()

    fun passwordStrength(pw: String): PasswordStrength = when {
        pw.length < 6 -> PasswordStrength.WEAK
        pw.length >= 10 && pw.any { !it.isLetterOrDigit() } -> PasswordStrength.STRONG
        pw.any(Char::isDigit) && pw.any(Char::isLetter) -> PasswordStrength.MEDIUM
        else -> PasswordStrength.WEAK
    }

    fun reset() { for (i in users.indices) users[i] = null; size = 0 }

    fun snapshot(): List<String> = users.mapIndexed { i, u -> "$i -> ${u?.email ?: "vacío"}" }
}
