package com.example.sum1.data

import android.content.Context
import androidx.annotation.VisibleForTesting
import com.example.sum1.data.local.DbContract
import com.example.sum1.data.local.DbHelper

private const val MAX_USERS = 5

enum class PasswordStrength { WEAK, MEDIUM, STRONG }

object UserRepository {

    // --- App real (SQLite) ---
    private var dao: UserDao? = null

    // --- Solo para UNIT TESTS (JVM) ---
    private var testUsers: MutableList<User>? = null
    private var nextIdForTests: Int = 1

    fun init(context: Context) {
        if (dao == null) {
            val db = DbHelper.getInstance(context).writableDatabase
            dao = UserDao(db)
        }
    }

    @VisibleForTesting
    fun initInMemoryForTests() {
        // No toques Android/SQLite aquí
        testUsers = mutableListOf()
        nextIdForTests = 1
    }

    fun reset() {
        testUsers?.let { it.clear(); nextIdForTests = 1; return }
        // Modo app real: limpiar tabla
        dao?.let {
            val db = DbHelper.getInstance((it as? Any) as? Context ?: return).writableDatabase
            // ^ Si no tienes Context aquí, simplemente:
            // dao!!.all() no te sirve para borrar; usa db directo desde init si lo guardas.
        }
        // Más simple: si estás en app real y quieres limpiar desde algún sitio de la app,
        // hazlo donde sí tengas Context, por ejemplo en un botón "limpiar".
    }

    fun register(email: String, password: String): Result<Unit> {
        val e = email.trim()
        if (e.isBlank() || password.isBlank())
            return Result.failure(IllegalArgumentException("Email/contraseña obligatorios"))

        testUsers?.let { list ->
            if (list.size >= MAX_USERS)
                return Result.failure(IllegalStateException("Capacidad máxima alcanzada ($MAX_USERS)"))
            if (list.any { it.email.equals(e, true) })
                return Result.failure(IllegalArgumentException("El usuario ya existe"))

            list += User(id = nextIdForTests++, email = e, password = password)
            return Result.success(Unit)
        }

        val d = dao ?: return Result.failure(IllegalStateException("Repositorio no inicializado"))
        if (d.count() >= MAX_USERS)
            return Result.failure(IllegalStateException("Capacidad máxima alcanzada ($MAX_USERS)"))
        if (d.findByEmail(e) != null)
            return Result.failure(IllegalArgumentException("El usuario ya existe"))
        return runCatching { d.insert(e, password); Unit }
    }

    fun login(email: String, password: String): Boolean {
        testUsers?.let { list ->
            return list.any { it.email.equals(email.trim(), true) && it.password == password }
        }
        return dao?.login(email, password) ?: false
    }

    fun recover(email: String): Boolean {
        testUsers?.let { list ->
            return list.any { it.email.equals(email.trim(), true) }
        }
        return dao?.recover(email) ?: false
    }

    fun allUsers(): List<User> {
        testUsers?.let { return it.toList() }
        return dao?.all() ?: emptyList()
    }

    fun passwordStrength(pw: String): PasswordStrength = when {
        pw.length < 6 -> PasswordStrength.WEAK
        pw.length >= 10 && pw.any { !it.isLetterOrDigit() } -> PasswordStrength.STRONG
        pw.any(Char::isDigit) && pw.any(Char::isLetter) -> PasswordStrength.MEDIUM
        else -> PasswordStrength.WEAK
    }

    fun snapshot(): List<String> =
        allUsers().mapIndexed { i, u -> "$i -> ${u.email}" }
}
