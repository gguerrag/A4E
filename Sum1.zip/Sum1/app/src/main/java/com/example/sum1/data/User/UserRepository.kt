package com.example.sum1.data.User

import androidx.compose.runtime.mutableStateListOf

class UserRepository {
    private const val MAX_USERS = 5
    private val _users = mutableStateListOf<User>()
    val users: List<User> get() = _users

    fun register(email: String, password: String): Result<Unit> {
        if (_users.size >= MAX_USERS) return Result.failure(IllegalStateException("Límite de 5 usuarios alcanzado"))
        if (_users.any { it.email.equals(email, ignoreCase = true) }) {
            return Result.failure(IllegalArgumentException("Ya existe un usuario con ese correo"))
        }
        _users.add(User(email.trim(), password))
        return Result.success(Unit)
    }

    fun login(email: String, password: String): Boolean =
        _users.any { it.email.equals(email, true) && it.password == password }

    fun recover(email: String): Boolean =
        _users.any { it.email.equals(email, true) }
}