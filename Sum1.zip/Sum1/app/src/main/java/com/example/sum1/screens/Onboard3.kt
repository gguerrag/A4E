package com.example.sum1.screens

import androidx.compose.runtime.Composable


@Composable
fun Onboard1Screen(onNext: () -> Unit) = OnboardCommon(
    rawRes = null, // o R.raw.tu_animacion
    title = "Bienvenido",
    description = "La app te ayuda a dictar y escuchar tus mensajes.",
    actionText = "Siguiente",
    onNext = onNext
)