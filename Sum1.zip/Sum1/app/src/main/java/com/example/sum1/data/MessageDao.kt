package com.example.sum1.data.local

import android.content.ContentValues
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import com.example.sum1.data.Message

class MessageDao(private val db: SQLiteDatabase) {

    fun insert(text: String, userId: Long): Long {
        val cv = ContentValues().apply {
            put(DbContract.Messages.TEXT, text)
            put(DbContract.Messages.USER_ID, userId)
            put(DbContract.Messages.CREATED_AT, System.currentTimeMillis())
        }
        return db.insertOrThrow(DbContract.Messages.TABLE, null, cv)
    }

    fun last(limit: Int = 50, userId: Long): List<Message> =
        db.query(
            DbContract.Messages.TABLE,
            arrayOf(DbContract.Messages.ID, DbContract.Messages.TEXT, DbContract.Messages.USER_ID, DbContract.Messages.CREATED_AT),
            "${DbContract.Messages.USER_ID}=?",
            arrayOf(userId.toString()),
            null, null,
            "${DbContract.Messages.CREATED_AT} DESC",
            limit.toString()
        ).use { read(it) }

    fun lastOne(userId: Long): Message? =
        db.query(
            DbContract.Messages.TABLE,
            arrayOf(DbContract.Messages.ID, DbContract.Messages.TEXT, DbContract.Messages.USER_ID, DbContract.Messages.CREATED_AT),
            "${DbContract.Messages.USER_ID}=?",
            arrayOf(userId.toString()),
            null, null,
            "${DbContract.Messages.CREATED_AT} DESC",
            "1"
        ).use { if (it.moveToFirst()) parse(it) else null }

    private fun read(c: Cursor): List<Message> {
        val out = ArrayList<Message>(c.count)
        while (c.moveToNext()) out += parse(c)
        return out
    }
    private fun parse(c: Cursor) = Message(
        id = c.getLong(0),
        text = c.getString(1),
        userId = c.getLong(2),
        createdAt = c.getLong(3)
    )
}
