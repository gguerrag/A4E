package com.example.sum1

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.sum1.data.UserRepository
import com.example.sum1.nav.NavRouter
import com.example.sum1.screens.*
import com.example.sum1.viewmodel.AuthViewModel
import com.example.sum1.viewmodel.DeviceViewModel
import com.example.sum1.viewmodel.MessageViewModel

class MainActivity : ComponentActivity() {

    // ViewModels
    private val authVM: AuthViewModel by viewModels()
    private val messageVM: MessageViewModel by viewModels()   // <- para HablarScreen
    private val deviceVM: DeviceViewModel by viewModels()     // <- para BuscarDispositivoScreen

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Inicializa SQLite (DbHelper + UserDao)
        UserRepository.init(applicationContext)

        setContent {
            Surface(color = MaterialTheme.colorScheme.background) {
                val nav = rememberNavController()

                NavHost(
                    navController = nav,
                    startDestination = NavRouter.Onboard1.route
                ) {
                    // --- ONBOARDING ---
                    composable(NavRouter.Onboard1.route) {
                        Onboard1Screen(onNext = { nav.navigate(NavRouter.Onboard2.route) })
                    }
                    composable(NavRouter.Onboard2.route) {
                        Onboard2Screen(onNext = { nav.navigate(NavRouter.Onboard3.route) })
                    }
                    composable(NavRouter.Onboard3.route) {
                        Onboard3Screen(onNext = { nav.navigate(NavRouter.Onboard4.route) })
                    }
                    composable(NavRouter.Onboard4.route) {
                        Onboard4Screen(onNext = { nav.navigate(NavRouter.Login.route) })
                    }

                    // --- LOGIN / REGISTRO / RECUPERAR ---
                    composable(NavRouter.Login.route) {
                        LoginScreen(
                            vm = authVM,
                            onRegister = { nav.navigate(NavRouter.Register.route) },
                            onForgot   = { nav.navigate(NavRouter.Forgot.route) },
                            onLoggedIn = {
                                nav.navigate(NavRouter.HomeMenu.route) {
                                    popUpTo(NavRouter.Login.route) { inclusive = true }
                                }
                            }
                        )
                    }

                    composable(NavRouter.Register.route) {
                        RegisterScreen(vm = authVM) {
                            nav.popBackStack()
                            nav.navigate(NavRouter.Login.route)
                        }
                    }

                    composable(NavRouter.Forgot.route) {
                        ForgotPasswordScreen(vm = authVM) {
                            nav.popBackStack()
                        }
                    }

                    // --- HOME MENÚ ---
                    composable(NavRouter.HomeMenu.route) {
                        HomeMenuScreen(
                            onGoSpeak  = { nav.navigate(NavRouter.Hablar.route) },
                            onGoSearch = { nav.navigate(NavRouter.Buscar.route) },
                            onGoWrite  = { /* nav.navigate(NavRouter.Escribir.route) si la agregas */ },
                            onLogout   = {
                                // authVM.logout() si lo implementas
                                nav.navigate(NavRouter.Login.route) {
                                    popUpTo(NavRouter.HomeMenu.route) { inclusive = true }
                                }
                            }
                        )
                    }

                    // --- FUNCIONES ---
                    composable(NavRouter.Hablar.route) {
                        // HablarScreen necesita MessageViewModel
                        HablarScreen(
                            vm = messageVM,
                            onBack = { nav.popBackStack() }
                        )
                    }

                    composable(NavRouter.Buscar.route) {
                        // BuscarDispositivoScreen necesita DeviceViewModel
                        BuscarDispositivoScreen(
                            vm = deviceVM,
                            onBack = { nav.popBackStack() }  // <- corregido (antes estaba 'popBackSt')
                        )
                    }

                    // Si más adelante creas EscribirScreen:
                    // composable(NavRouter.Escribir.route) {
                    //     EscribirScreen(vm = messageVM, onBack = { nav.popBackStack() })
                    // }
                }
            }
        }
    }
}
