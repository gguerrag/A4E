package com.example.sum1

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.sum1.nav.NavRouter
import com.example.sum1.screens.*
import com.example.sum1.viewmodel.AuthViewModel
import com.example.sum1.ui.theme.Sum1Theme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {

            Sum1Theme {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    val nav = rememberNavController()
                    val vm: AuthViewModel = viewModel()

                    NavHost(navController = nav, startDestination = NavRouter.Onboard1.route) {
                        composable(NavRouter.Onboard1.route) { Onboard1Screen { nav.navigate(NavRouter.Onboard2.route) } }
                        composable(NavRouter.Onboard2.route) { Onboard2Screen { nav.navigate(NavRouter.Onboard3.route) } }
                        composable(NavRouter.Onboard3.route) { Onboard3Screen { nav.navigate(NavRouter.Onboard4.route) } }
                        composable(NavRouter.Onboard4.route) { Onboard4Screen { nav.navigate(NavRouter.Login.route) } }

                        composable(NavRouter.Login.route) {
                            LoginScreen(
                                vm = vm,
                                onRegister = { nav.navigate(NavRouter.Register.route) },
                                onForgot = { nav.navigate(NavRouter.Forgot.route) },
                                onLoggedIn = { nav.navigate(NavRouter.Home.route) }
                            )
                        }
                        composable(NavRouter.Register.route) {
                            RegisterScreen(vm = vm) { nav.popBackStack(); nav.navigate(NavRouter.Login.route) }
                        }
                        composable(NavRouter.Forgot.route) {
                            ForgotPasswordScreen(vm = vm) { nav.popBackStack() }
                        }
                        composable(NavRouter.Home.route) { HomeScreen() }
                    }
                }
            }
        }
    }
}
