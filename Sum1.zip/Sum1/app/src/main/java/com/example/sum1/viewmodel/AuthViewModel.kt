package com.example.sum1.viewmodel

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import com.example.sum1.data.PasswordStrength
import com.example.sum1.data.User
import com.example.sum1.data.UserRepository
import com.example.sum1.util.isValidEmail

class AuthViewModel : ViewModel() {

    var email by mutableStateOf("")
    var password by mutableStateOf("")
    var message by mutableStateOf<String?>(null)
    var strength by mutableStateOf<PasswordStrength?>(null)
    var users by mutableStateOf<List<User>>(emptyList())
        private set
    var currentUser: User? = null
        private set

    fun onEmailChange(v: String) { email = v }
    fun onPasswordChange(v: String) {
        password = v
        strength = if (v.isEmpty()) null else UserRepository.passwordStrength(v)
    }

    fun doLogin(): Boolean {
        val ok = UserRepository.login(email, password)
        message = if (ok) null else "Credenciales inválidas"
        if (ok) users = UserRepository.allUsers()
        return ok
    }

    fun doRegister(onSuccess: () -> Unit) {
        if (!email.isValidEmail()) { message = "Email inválido"; return }
        val res = UserRepository.register(email, password)
        if (res.isSuccess) {
            users = UserRepository.allUsers()
            email = ""; password = ""; strength = null
            message = "Usuario registrado correctamente"
            onSuccess()
        } else message = res.exceptionOrNull()?.message ?: "Error inesperado"
    }

    fun doRecover(): Boolean {
        val ok = UserRepository.recover(email)
        message = if (ok) "Te enviamos instrucciones (simulado)" else "Usuario no encontrado"
        return ok
    }
}
