package com.example.sum1.viewmodel

class AuthViewModel {
    var email by mutableStateOf("")
    var password by mutableStateOf("")
    var message by mutableStateOf<String?>(null)
        private set

    fun doLogin(): Boolean {
        val ok = UserRepository.login(email, password)
        message = if (ok) null else "Credenciales inválidas"
        return ok
    }

    fun doRegister(onSuccess: () -> Unit) {
        val res = UserRepository.register(email, password)
        message = res.exceptionOrNull()?.message
        if (res.isSuccess) onSuccess()
    }

    fun doRecover(): Boolean {
        val ok = UserRepository.recover(email)
        message = if (ok) "Te enviamos instrucciones (simulado)" else "Usuario no encontrado"
        return ok
    }
}