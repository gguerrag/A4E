package com.example.sum1.data
data class DeviceLocation(
    val id: Long = 0,
    val userId: Long,
    val lat: Double,
    val lng: Double,
    val recordedAt: Long = System.currentTimeMillis()
)
