package com.example.sum1.screens

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.airbnb.lottie.compose.*
import com.example.sum1.R

@Composable
fun Onboard1Screen(onNext: () -> Unit) = OnboardCommon(
    title = "Bienvenido a\nAccessibility 4 Everyone",
    description = "Esta aplicación está diseñada para asistir a personas con discapacidad visual.",
    actionText = "Siguiente",
    onNext = onNext,
    illustration = {
        val composition by rememberLottieComposition(
            LottieCompositionSpec.RawRes(R.raw.ear)
        )
        val progress by animateLottieCompositionAsState(
            composition = composition,
            iterations = LottieConstants.IterateForever
        )
        LottieAnimation(
            composition = composition,
            progress = { progress },
            modifier = Modifier
                .fillMaxWidth()
                .height(400.dp)
        )
    }
)
