package com.example.sum1.data
data class Message(
    val id: Long = 0,
    val text: String,
    val userId: Long,
    val createdAt: Long = System.currentTimeMillis()
)
