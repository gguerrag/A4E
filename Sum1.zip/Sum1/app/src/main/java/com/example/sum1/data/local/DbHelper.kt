package com.example.sum1.data.local

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DbHelper private constructor(ctx: Context)
    : SQLiteOpenHelper(ctx, DbContract.DB_NAME, null, DbContract.DB_VERSION) {

    override fun onConfigure(db: SQLiteDatabase) {
        super.onConfigure(db)
        db.execSQL("PRAGMA foreign_keys=ON")
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(DbContract.Users.CREATE)
        db.execSQL(DbContract.Messages.CREATE)
        db.execSQL(DbContract.Locations.CREATE)
    }

    override fun onUpgrade(db: SQLiteDatabase, old: Int, new: Int) {
    }

    companion object {
        @Volatile private var INSTANCE: DbHelper? = null
        fun getInstance(ctx: Context): DbHelper =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: DbHelper(ctx.applicationContext).also { INSTANCE = it }
            }
    }
}
