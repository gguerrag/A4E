package com.example.sum1.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.example.sum1.viewmodel.AuthViewModel

@Composable
fun LoginScreen(
    vm: AuthViewModel,
    onRegister: () -> Unit,
    onForgot: () -> Unit,
    onLoggedIn: () -> Unit
) {
    Column(Modifier.fillMaxSize().padding(24.dp)) {
        Text("Iniciar sesión",
            style = MaterialTheme.typography.headlineMedium
        )
        Spacer(Modifier.height(16.dp))

        OutlinedTextField(
            value = vm.email,
            onValueChange = { vm.email = it },
            label = { Text("Correo") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().semantics { contentDescription = "Campo correo" }
        )
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            value = vm.password,
            onValueChange = { vm.password = it },
            label = { Text("Contraseña") },
            singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth().semantics { contentDescription = "Campo contraseña" }
        )

        vm.message?.let { Spacer(Modifier.height(8.dp)); Text(it, color = MaterialTheme.colorScheme.error) }

        Spacer(Modifier.height(16.dp))
        Button(
            onClick = { if (vm.doLogin()) onLoggedIn() },
            modifier = Modifier.fillMaxWidth().height(56.dp)
        ) { Text("Entrar") }

        Spacer(Modifier.height(8.dp))
        TextButton(onClick = onForgot) { Text("¿Olvidaste tu contraseña?") }
        OutlinedButton(onClick = onRegister, modifier = Modifier.fillMaxWidth()) { Text("Crear cuenta") }
    }
}