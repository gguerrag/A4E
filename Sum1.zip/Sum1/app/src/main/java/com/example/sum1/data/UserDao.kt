package com.example.sum1.data

import android.content.ContentValues
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import com.example.sum1.data.local.DbContract

class UserDao(private val db: SQLiteDatabase) {
    fun count(): Int = db.rawQuery(
        "SELECT COUNT(*) FROM ${DbContract.Users.TABLE}", null
    ).use { c -> if (c.moveToFirst()) c.getInt(0) else 0 }

    fun all(): List<User> = db.query(
        DbContract.Users.TABLE,
        arrayOf(DbContract.Users.ID, DbContract.Users.EMAIL, DbContract.Users.PASSWORD),
        null, null, null, null, "${DbContract.Users.ID} ASC"
    ).use { c -> readUsers(c) }

    fun findByEmail(email: String): User? = db.query(
        DbContract.Users.TABLE,
        arrayOf(DbContract.Users.ID, DbContract.Users.EMAIL, DbContract.Users.PASSWORD),
        "${DbContract.Users.EMAIL} = ?",
        arrayOf(email.trim()), null, null, null
    ).use { c -> if (c.moveToFirst()) readUser(c) else null }

    fun insert(email: String, password: String): Long {
        val values = ContentValues().apply {
            put(DbContract.Users.EMAIL, email.trim())
            put(DbContract.Users.PASSWORD, password)
            put(DbContract.Users.CREATED_AT, System.currentTimeMillis())
        }
        return db.insertOrThrow(DbContract.Users.TABLE, null, values)
    }

    fun login(email: String, password: String): Boolean =
        db.rawQuery(
            "SELECT ${DbContract.Users.ID} FROM ${DbContract.Users.TABLE} " +
                    "WHERE ${DbContract.Users.EMAIL}=? AND ${DbContract.Users.PASSWORD}=? LIMIT 1",
            arrayOf(email.trim(), password)
        ).use { it.moveToFirst() }

    fun recover(email: String): Boolean =
        db.rawQuery(
            "SELECT 1 FROM ${DbContract.Users.TABLE} WHERE ${DbContract.Users.EMAIL}=? LIMIT 1",
            arrayOf(email.trim())
        ).use { it.moveToFirst() }

    private fun readUsers(c: Cursor): List<User> {
        val res = ArrayList<User>(c.count)
        while (c.moveToNext()) res.add(readUser(c))
        return res
    }

    private fun readUser(c: Cursor): User =
        User(
            id = c.getInt(0),
            email = c.getString(1),
            password = c.getString(2)
        )
}
