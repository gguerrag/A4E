package com.example.sum1.data

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import com.example.sum1.data.local.DbHelper
import com.example.sum1.data.local.MessageDao

object MessageRepository {
    private lateinit var db: SQLiteDatabase
    private lateinit var dao: MessageDao

    fun init(context: Context) {
        if (!::db.isInitialized) {
            db = DbHelper.getInstance(context).writableDatabase
            dao = MessageDao(db)
        }
    }

    fun send(text: String, userId: Long): Result<Long> = runCatching {
        require(text.isNotBlank()) { "Mensaje vacío" }
        dao.insert(text.trim(), userId)
    }

    fun last(userId: Long, limit: Int = 50): List<Message> = dao.last(limit, userId)
    fun lastOne(userId: Long): Message? = dao.lastOne(userId)
}
