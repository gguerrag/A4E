package com.example.sum1.screens;

public class OnboardCommon {
}
