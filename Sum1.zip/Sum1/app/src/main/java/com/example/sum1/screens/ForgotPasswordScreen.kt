package com.example.sum1.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.sum1.viewmodel.AuthViewModel

@Composable
fun ForgotPasswordScreen(vm: AuthViewModel, onDone: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(24.dp)) {
        Text("Recuperar contraseña", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(16.dp))
        OutlinedTextField(vm.email, { vm.email = it }, label = { Text("Correo") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(16.dp))
        Button(onClick = { if (vm.doRecover()) onDone() }, modifier = Modifier.fillMaxWidth().height(56.dp)) {
            Text("Enviar instrucciones")
        }
        vm.message?.let { Spacer(Modifier.height(8.dp)); Text(it) }
    }
}
