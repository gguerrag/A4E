package com.example.sum1.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.sum1.viewmodel.AuthViewModel

@Composable
fun ForgotPasswordScreen(vm: AuthViewModel, onBack: () -> Unit = {}) {
    Column(Modifier.padding(16.dp)) {
        Text("Recuperar contraseña", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = vm.email, onValueChange = vm::onEmailChange,
            label = { Text("Email") }, modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(8.dp))
        Button(onClick = { if (vm.doRecover()) onBack() }) { Text("Enviar correo") }
        if (vm.message != null) {
            Spacer(Modifier.height(8.dp))
            Text(vm.message!!, color = MaterialTheme.colorScheme.error)
        }
    }
}
