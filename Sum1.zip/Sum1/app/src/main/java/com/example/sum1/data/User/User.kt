package com.example.sum1.data.User

class User {
    data class User(val email: String, val password: String)

}