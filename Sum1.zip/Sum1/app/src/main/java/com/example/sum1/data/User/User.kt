package com.example.sum1.data

data class User(
    val id: Int,
    val email: String,
    val password: String
)
