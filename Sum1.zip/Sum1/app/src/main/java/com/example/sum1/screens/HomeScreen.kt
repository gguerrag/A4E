package com.example.sum1.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import com.example.sum1.util.TTSManager
import com.example.sum1.util.sttIntent

@Composable
fun HomeScreen() {
    val tts = remember { TTSManager(LocalContext.current) }
    var input by remember { mutableStateOf(TextFieldValue("")) }
    val mensajes = remember { mutableStateListOf<String>() }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        val data = res.data
        val matches = data?.getStringArrayListExtra(android.speech.RecognizerIntent.EXTRA_RESULTS)
        matches?.firstOrNull()?.let { input = TextFieldValue(it) }
    }

    DisposableEffect(Unit) { onDispose { tts.shutdown() } }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Comunicación accesible", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(12.dp))

        LazyColumn(Modifier.weight(1f)) {
            items(mensajes) { msg ->
                Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                    Row(Modifier.padding(12.dp)) {
                        Text(msg, modifier = Modifier.weight(1f))
                        TextButton(onClick = { tts.speak(msg) }) { Text("Leer") }
                    }
                }
            }
        }

        OutlinedTextField(value = input, onValueChange = { input = it }, label = { Text("Escribe o usa dictado") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        Row {
            Button(
                onClick = {
                    if (input.text.isNotBlank()) { mensajes.add(input.text); input = TextFieldValue("") }
                },
                modifier = Modifier.weight(1f).height(56.dp)
            ) { Text("Enviar") }

            Spacer(Modifier.width(8.dp))

            OutlinedButton(
                onClick = { launcher.launch(sttIntent()) },
                modifier = Modifier.weight(1f).height(56.dp)
            ) { Text("Dictado") }
        }
    }
}
