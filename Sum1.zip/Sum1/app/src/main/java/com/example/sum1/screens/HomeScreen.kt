package com.example.sum1.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp

@Composable
fun HomeMenuScreen(
    onGoSpeak: () -> Unit,
    onGoSearch: () -> Unit,
    onGoWrite: () -> Unit = {},
    onLogout: () -> Unit = {}
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "Menú principal",
            style = MaterialTheme.typography.headlineMedium
        )

        Button(
            modifier = Modifier
                .fillMaxWidth()
                .semantics { contentDescription = "Abrir función hablar" },
            onClick = onGoSpeak
        ) { Text("Hablar (TTS/STT)") }

        Button(
            modifier = Modifier
                .fillMaxWidth()
                .semantics { contentDescription = "Buscar dispositivo cercano" },
            onClick = onGoSearch
        ) { Text("Buscar dispositivo") }

        Button(
            modifier = Modifier
                .fillMaxWidth()
                .semantics { contentDescription = "Escribir mensaje" },
            onClick = onGoWrite
        ) { Text("Escribir") }

        Button(
            modifier = Modifier
                .fillMaxWidth()
                .semantics { contentDescription = "Cerrar sesión" },
            onClick = onLogout
        ) { Text("Cerrar sesión") }
    }
}
