package com.example.sum1.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun HomeMenuScreen(onEscribir: ()->Unit, onHablar: ()->Unit, onBuscar: ()->Unit) {
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Home", style = MaterialTheme.typography.headlineMedium)
        Button(onClick = onEscribir, modifier = Modifier.fillMaxWidth().height(56.dp)) { Text("Escribir") }
        Button(onClick = onHablar,   modifier = Modifier.fillMaxWidth().height(56.dp)) { Text("Hablar") }
        Button(onClick = onBuscar,   modifier = Modifier.fillMaxWidth().height(56.dp)) { Text("Buscar dispositivo") }
    }
}
