package com.example.sum1.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.example.sum1.viewmodel.AuthViewModel

@Composable
fun RegisterScreen(vm: AuthViewModel, onRegistered: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(24.dp)) {
        Text("Registro", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(16.dp))
        OutlinedTextField(vm.email, { vm.email = it }, label = { Text("Correo") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(vm.password, { vm.password = it }, label = { Text("Contraseña (mín. 6)") },
            singleLine = true, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
        vm.message?.let { Spacer(Modifier.height(8.dp)); Text(it, color = MaterialTheme.colorScheme.error) }
        Spacer(Modifier.height(16.dp))
        Button(
            onClick = {
                if (vm.password.length < 6) vm.message = "La contraseña debe tener al menos 6 caracteres"
                else vm.doRegister(onRegistered)
            },
            modifier = Modifier.fillMaxWidth().height(56.dp)
        ) { Text("Crear cuenta") }
        Spacer(Modifier.height(8.dp))
        Text("Nota: se guardan hasta 5 usuarios en memoria para esta entrega.", style = MaterialTheme.typography.bodySmall)
    }
}
