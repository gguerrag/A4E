package com.example.sum1.data.local

import android.content.ContentValues
import android.database.sqlite.SQLiteDatabase
import com.example.sum1.data.DeviceLocation

class LocationDao(private val db: SQLiteDatabase) {

    fun insert(uid: Long, lat: Double, lng: Double): Long {
        val cv = ContentValues().apply {
            put(DbContract.Locations.USER_ID, uid)
            put(DbContract.Locations.LAT, lat)
            put(DbContract.Locations.LNG, lng)
            put(DbContract.Locations.RECORDED_AT, System.currentTimeMillis())
        }
        return db.insertOrThrow(DbContract.Locations.TABLE, null, cv)
    }

    fun last(uid: Long): DeviceLocation? =
        db.rawQuery(
            "SELECT id, userId, lat, lng, recordedAt FROM ${DbContract.Locations.TABLE} " +
                    "WHERE userId=? ORDER BY recordedAt DESC LIMIT 1",
            arrayOf(uid.toString())
        ).use { c ->
            if (!c.moveToFirst()) null else DeviceLocation(
                id = c.getLong(0), userId = c.getLong(1),
                lat = c.getDouble(2), lng = c.getDouble(3), recordedAt = c.getLong(4)
            )
        }
}
