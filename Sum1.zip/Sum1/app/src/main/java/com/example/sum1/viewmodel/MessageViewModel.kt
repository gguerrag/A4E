package com.example.sum1.viewmodel

import android.app.Application
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.sum1.data.Message
import com.example.sum1.data.MessageRepository
import com.example.sum1.data.UserRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class MessageViewModel(app: Application) : AndroidViewModel(app) {

    init { MessageRepository.init(app) }

    val input = mutableStateOf("")
    val items = mutableStateListOf<Message>()
    val error = mutableStateOf<String?>(null)

    private fun currentUserIdOrThrow(): Long =
        UserRepository.allUsers().firstOrNull { it.email.equals(currentEmail(), true) }?.id?.toLong()
            ?: UserRepository.allUsers().firstOrNull()?.id?.toLong()
            ?: throw IllegalStateException("No hay usuario actual")


    private fun currentEmail(): String = ""

    fun refresh() = viewModelScope.launch(Dispatchers.IO) {
        error.value = null
        val uid = runCatching { currentUserIdOrThrow() }.getOrElse {
            error.value = it.message; return@launch
        }
        val list = MessageRepository.last(uid)
        items.clear(); items.addAll(list)
    }

    fun send() = viewModelScope.launch(Dispatchers.IO) {
        error.value = null
        val uid = runCatching { currentUserIdOrThrow() }.getOrElse {
            error.value = it.message; return@launch
        }
        val text = input.value
        val res = MessageRepository.send(text, uid)
        if (res.isSuccess) {
            input.value = ""
            refresh()
        } else error.value = res.exceptionOrNull()?.message
    }
}
