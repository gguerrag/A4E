package com.example.sum1

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.example.sum1.data.User
import com.example.sum1.data.UserDao
import com.example.sum1.data.local.DbContract
import com.example.sum1.data.local.DbHelper
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class UserDaoInstrumentedTest {

    private lateinit var ctx: Context
    private lateinit var dao: UserDao

    @Before
    fun setup() {
        ctx = ApplicationProvider.getApplicationContext()
        val db = DbHelper.getInstance(ctx).writableDatabase

        db.delete(DbContract.Users.TABLE, null, null)
        dao = UserDao(db)
    }

    @Test
    fun insert_and_login_ok() {
        val email = "hola@hola.com"
        val pass = "123456"
        val id = dao.insert(email, pass)
        assertTrue(id > 0)
        assertTrue(dao.login(email, pass))
        val found: User? = dao.findByEmail(email)
        assertEquals(email, found?.email)
    }
}
