package com.example.sum1

import com.example.sum1.data.UserRepository
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

class UserRepositoryTest {

    @Before
    fun setup() {
        UserRepository.initInMemoryForTests()
        UserRepository.reset()
    }

    @Test
    fun register_and_login_ok() {
        val email = "test@test.com"
        val pass = "123456"
        val res = UserRepository.register(email, pass)
        assertTrue(res.isSuccess)
        assertTrue(UserRepository.login(email, pass))
    }

    @Test
    fun duplicate_register_fails() {
        UserRepository.register("a@b.com", "123456")
        val res = UserRepository.register("a@b.com", "123456")
        assertTrue(res.isFailure)
    }
}
